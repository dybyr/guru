package com.example.beepme
import android.content.ContentValues
import android.content.Context
import android.content.SharedPreferences
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.get
import androidx.core.view.size

class AllergyActivity : AppCompatActivity() {

    lateinit var gridView: GridLayout
    lateinit var btndone: Button
    lateinit var btnchange: Button
    private lateinit var dbHelper: DBHelper
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_allergy)

        dbHelper = DBHelper(this) //데이터베이스 작업 수행을 위한 객체
        gridView = findViewById(R.id.gridLayout) //알러지 선택 화면 gridview
        sharedPreferences = getPreferences(Context.MODE_PRIVATE) //현재 앱 안에서 접근 가능한 sharedPreferences 생성

        // 알러지 리스트
        val allergy = arrayOf(
            "호두", "게", "새우", "오징어", "복숭아", "토마토", "닭고기", "돼지고기",
            "난류", "우유", "메밀", "땅콩", "대두", "밀", "잣", "고등어", "소고기", "아황산류", "조개류"
        )

        // 그리드 레이아웃에 버튼 추가
        for (item in allergy) {
            val button = Button(this)
            button.text = item
            button.tag = item // 버튼에 고유한 태그 설정
            button.setOnClickListener {
                toggleButtonSelection(button)
                saveButtonSelection(button)
            }
            val params = GridLayout.LayoutParams()
            params.width = 0 // 너비를 0으로 설정
            params.height = GridLayout.LayoutParams.WRAP_CONTENT
            params.rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1)
            params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1, 1f) // 가중치를 1로 설정
            params.setMargins(8, 8, 8, 8) // 버튼 간격 조절
            button.layoutParams = params
            gridView.addView(button)
            restoreButtonSelection(button)
        }

        // 완료 버튼을 누르면 데이터베이스에 선택한 알러지 저장
        btndone = findViewById(R.id.btndone)
        btndone.setOnClickListener {
            try {
                saveSelectedItemsToDatabase()
                Toast.makeText(this, "알러지 선택이 저장되었습니다.", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "알러지 선택 저장 중 오류 발생", Toast.LENGTH_SHORT).show()
                e.printStackTrace()
            }
        }

        // 알러지를 다시 선택한 후에 수정 버튼을 누르면 수정된 알러지 데이터베이스에 저장
        btnchange = findViewById(R.id.btnchange)
        //btnchange 버튼에 클릭 리스너 등록
        btnchange.setOnClickListener {
            try {
                //updateDatabase() 메서드를 호출하여 데이터베이스를 업데이트
                updateDatabase()
                //데이터베이스 업데이트 성공 시 사용자에게 알림 메시지를 토스트 형태로 표시
                Toast.makeText(this, "알러지 선택이 수정되었습니다.", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                //updateDatabase() 수행 중 예외가 발생한 경우, 오류 메시지를 토스트 형태로 표시
                Toast.makeText(this, "알러지 선택 수정 중 오류 발생", Toast.LENGTH_SHORT).show()
                e.printStackTrace()
            }
        }
    }

    private fun toggleButtonSelection(button: Button) {
        //버튼의 isSelected 속성을 현재 상태의 반대로 토글
        button.isSelected = !button.isSelected
        if (button.isSelected) {
            //버튼이 선택된 경우, 배경 색상을 노란색으로 설정
            button.setBackgroundColor(ContextCompat.getColor(this, R.color.yellow))
        } else {
            //버튼이 선택되지 않은 경우, 배경 색상을 회색으로 설정
            button.setBackgroundColor(ContextCompat.getColor(this, android.R.color.darker_gray))
        }
    }

    private fun restoreButtonSelection(button: Button) {
        //sharedPreferences에서 해당 버튼의 선택 상태를 불러옴
        val isSelected = sharedPreferences.getBoolean(button.tag.toString(), false)
        //버튼의 isSelected 속성을 sharedPreferences에서 불러온 값으로 설정하여 선택 상태를 복원
        button.isSelected = isSelected
        //버튼이 선택된 상태인지 여부에 따라 배경 색상을 설정
        if (isSelected) {
            //버튼이 선택된 경우, 배경 색상을 노란색으로 설정
            button.setBackgroundColor(ContextCompat.getColor(this, R.color.yellow))
        } else {
            //버튼이 선택되지 않은 경우, 배경 색상을 회색으로 설정
            button.setBackgroundColor(ContextCompat.getColor(this, android.R.color.darker_gray))
        }
    }

    private fun saveButtonSelection(button: Button) {
        //sharedPreferences에 데이터를 수정하기 위한 editor 객체를 얻어옴
        val editor = sharedPreferences.edit()
        //버튼의 tag 속성을 사용하여 해당 버튼의 선택 상태를 sharedPreferences에 저장
        editor.putBoolean(button.tag.toString(), button.isSelected)
        //변경된 데이터를 적용
        editor.apply()
    }

    private fun saveSelectedItemsToDatabase() {
        //선택된 항목들을 저장할 빈 문자열 리스트를 생성
        val selectedItems = mutableListOf<String>()

        //그리드뷰의 각 자식(버튼)에 대해 반복함
        for (i in 0 until gridView.childCount) {
            //그리드뷰의 i번째 자식을 버튼으로 캐스팅
            val button = gridView.getChildAt(i) as Button
            //버튼이 선택된 상태인지 확인하고, 선택된 경우 버튼의 tag 값을 리스트에 추가
            if (button.isSelected) {
                selectedItems.add(button.tag.toString())
            }
        }

        //DBHelper 클래스의 saveSelectedItems 메서드를 호출하여 선택된 항목들을 데이터베이스에 저장
        dbHelper.saveSelectedItems(selectedItems)
    }

    private fun updateDatabase() {
        //선택된 항목들을 저장할 빈 문자열 리스트를 생성
        val selectedItems = mutableListOf<String>()

        //그리드뷰의 각 자식(버튼)에 대해 반복
        for (i in 0 until gridView.childCount) {
            //그리드뷰의 i번째 자식을 버튼으로 캐스팅
            val button = gridView.getChildAt(i) as Button
            //버튼이 선택된 상태인지 확인하고, 선택된 경우 버튼의 tag 값을 리스트에 추가
            if (button.isSelected) {
                selectedItems.add(button.tag.toString())
            }
        }

        //DBHelper 클래스의 updateSelectedItems 메서드를 호출하여 선택된 항목들을 데이터베이스에 업데이트
        dbHelper.updateSelectedItems(selectedItems)
    }

    private class DBHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {
        //companion object를 사용하여 클래스의 정적 상수를 정의함
        companion object {
            const val DATABASE_NAME = "selected_items"
            const val DATABASE_VERSION = 1
            const val TABLE_NAME = "selected_items"
            const val COLUMN_NAME = "item_name"
        }

        override fun onCreate(db: SQLiteDatabase?) {
            //선택된 항목들을 저장할 테이블을 생성하는 SQL 쿼리를 작성하고 실행
            val createTableQuery = "CREATE TABLE $TABLE_NAME ($COLUMN_NAME TEXT)"
            db?.execSQL(createTableQuery)
        }

        override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        }

        fun saveSelectedItems(selectedItems: List<String>) {
            //쓰기 가능한 데이터베이스 객체를 얻어옴
            val db = writableDatabase

            //선택된 각 항목에 대해 ContentValues를 생성하고, 해당 항목을 데이터베이스에 삽입
            for (item in selectedItems) {
                val values = ContentValues().apply {
                    put(COLUMN_NAME, item)
                }
                db.insert(TABLE_NAME, null, values)
            }
            //데이터베이스 사용이 끝나면 닫음
            db.close()
        }

        fun updateSelectedItems(selectedItems: List<String>) {
            //쓰기 가능한 데이터베이스 객체를 얻어옴
            val db = writableDatabase
            //트랜잭션 시작
            db.beginTransaction()

            try {
                //기존 데이터베이스에서 모든 항목을 삭제
                db.delete(TABLE_NAME, null, null)

                //새로운 항목들을 데이터베이스에 삽입
                for (item in selectedItems) {
                    val values = ContentValues().apply {
                        put(COLUMN_NAME, item)
                    }
                    db.insert(TABLE_NAME, null, values)
                }

                //트랜잭션을 성공으로 표시
                db.setTransactionSuccessful()
            } finally {
                //트랜잭션 종료
                db.endTransaction()
            }

            //데이터베이스 사용이 끝나면 닫음
            db.close()
        }
    }
}
